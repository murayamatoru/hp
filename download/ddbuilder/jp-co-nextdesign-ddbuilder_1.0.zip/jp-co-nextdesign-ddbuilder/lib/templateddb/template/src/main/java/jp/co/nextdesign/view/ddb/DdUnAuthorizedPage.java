/*
 * DDBuilder%DDB_VERSION%が生成したファイルです。%FILE_GENERATED_AT%
 */
package jp.co.nextdesign.view.ddb;

import org.apache.wicket.markup.html.WebPage;

public class DdUnAuthorizedPage extends WebPage {

	private static final long serialVersionUID = 1L;
	
	/** コンストラクタ */
	public DdUnAuthorizedPage() {
		super();
	}	
}
