package jp.co.nextdesign.service;

public class MyClass {

}
