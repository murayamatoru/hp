package jp.co.nextdesign.view;

import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.panel.Panel;
import org.apache.wicket.model.IModel;

/**
 * 
 */
public class SelectActionPanel extends Panel
{
	private static final long serialVersionUID = 1L;
	private Contact selected;
	private DataTablePage parentPage;

	/**
	 * 
	 */
	public SelectActionPanel(String id, IModel<Contact> model, DataTablePage parentPage)
	{
		super(id, model);
		this.parentPage = parentPage;
		add(new Link<String>("select")
		{
			private static final long serialVersionUID = 1L;
			@Override
			public void onClick()
			{
				selected = (Contact)getParent().getDefaultModelObject();
				if (SelectActionPanel.this.parentPage != null ){
					SelectActionPanel.this.parentPage.setSelected(selected);
				}
			}
		});
	}
}
