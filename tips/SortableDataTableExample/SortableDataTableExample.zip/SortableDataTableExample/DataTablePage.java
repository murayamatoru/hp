package jp.co.nextdesign.view;

import java.util.ArrayList;
import java.util.List;

import org.apache.wicket.extensions.markup.html.repeater.data.grid.ICellPopulator;
import org.apache.wicket.extensions.markup.html.repeater.data.table.AbstractColumn;
import org.apache.wicket.extensions.markup.html.repeater.data.table.DefaultDataTable;
import org.apache.wicket.extensions.markup.html.repeater.data.table.IColumn;
import org.apache.wicket.extensions.markup.html.repeater.data.table.PropertyColumn;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.panel.FeedbackPanel;
import org.apache.wicket.markup.repeater.Item;
import org.apache.wicket.model.IModel;
import org.apache.wicket.model.Model;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.model.StringResourceModel;

public class DataTablePage extends WebPage {
	private static final long serialVersionUID = 1L;
	
	private Contact selected;
	
	public DataTablePage() {
		
		add(new Label("selectedLabel", new PropertyModel<>(this, "selectedContactLabel")));
		add(new FeedbackPanel("feedback"));
		
        final UserProvider userProvider = new UserProvider();
        List<IColumn<Contact,String>> columns = new ArrayList<IColumn<Contact,String>>();
        //アクションありの列
        columns.add(new AbstractColumn<Contact,String>(new Model<String>("Actions")){
        	private static final long serialVersionUID = 1L;
        	@Override
        	public void populateItem(Item<ICellPopulator<Contact>> cellItem, String componentId, IModel<Contact> model){
        		cellItem.add(new SelectActionPanel(componentId, model, DataTablePage.this));
        	}
       });
        //文字列をDataTablePage.propertiesからキー"firstNameTableHeaderLabel"で取得するケース
        columns.add(new PropertyColumn<Contact,String>(new StringResourceModel("firstNameTableHeaderLabel", this, null), "name.first", "name.first"));
        //ソートあり
        columns.add(new PropertyColumn<Contact,String>(new Model<String>("Last Name"), "name.last", "name.last"));
        //ソートなし、個別にスタイルを適用
        columns.add(new PropertyColumn<Contact,String>(new Model<String>("電話番号"), "name.homePhone"){
        	private static final long serialVersionUID = 1L;
        	@Override
        	public String getCssClass(){
        		return "phone-number";
        	}
        });
        DefaultDataTable<Contact,String> table = new DefaultDataTable<Contact,String>("datatable", columns, userProvider, 3);
        add(table);
        //DataTableが自動で追加するので次の2行は不要 2017.1.28
        //PagingNavigator pagingNavigator = new PagingNavigator("pagingNavigator", table);
        //add(pagingNavigator);
    }
	
	/**
	 * @return string representation of selected contact property
	 */
	public String getSelectedContactLabel()
	{
		if (selected == null)
		{
			return "No Contact Selected";
		}
		else
		{
			return selected.getName().getFirst() + " " + selected.getName().getLast();
		}
	}

	public void setSelected(Contact selected) {
		this.selected = selected;
	}
}