/*
 * DDBuilder%DDB_VERSION%が生成したファイルです。%FILE_GENERATED_AT%
 */
package jp.co.nextdesign.domain.ddb;

/**
 * OrderBy 昇順・降順
 * @author murayama
 *
 */
public enum DdSortOrder {
	ASC,
	DESC
}
